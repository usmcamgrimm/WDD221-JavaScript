/*

    Adrian Grimm
	WDD221 Javascript
	Week 4 - Exam 1!
	Temperature Converter
	2/8/2019

*/