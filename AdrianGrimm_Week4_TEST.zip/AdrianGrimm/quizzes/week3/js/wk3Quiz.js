/*
	Adrian Grimm
	WDD221 JavaScript
	Quiz - Week 3
	2/3/2019
*/
console.log('hi!'.length);

/*
1. The outcome of this statement is 3, which is the number of characters in the string.
*/

/*
2. A boolean type is reporesented as:
	true false
*/

console.log('Hello world');
/*
3.The output of the statement is:
	Hello world is printed to the console
*/

let x = 5
console.log(x *= 2);
/*
4. The following will reassign x to 10:
	x *= 2
*/

/*
5. Declaring a variable you can change:
	let myName = 'Mickey';
*/

/*
6. Variables in JavaScript are used for:
	Storing or holding data values
*/

/*
7. Correct way to call a string's built-in method:
	'javascript'.toUpperCase();
*/

/*
8. String interpolation:
	When you insert the value of a variable into a string
*/

/*
9. The following code snippet causes an error:
	const food = 'chicken';
	food = 'pizza';
*/

/*
10. Correct way to call the random method in the Math library:
	//Math.random()
*/