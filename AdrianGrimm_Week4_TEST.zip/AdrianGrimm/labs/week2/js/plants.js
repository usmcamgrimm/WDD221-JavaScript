/*
	Adrian Grimm
	WDD221 - Web Development with JavaScript
	Week 2 Lab
	1/26/2019
*/

//Variable Definition of img src files
let blanket = "images/blanket.jpg";
let bluestem = "images/bluestem.jpg";
let rugosa = "images/rugosa.jpg";