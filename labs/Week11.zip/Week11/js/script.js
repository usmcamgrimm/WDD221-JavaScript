/*  
	JavaScript Lab


// create a new function named display that passes a parameter named event
function display(event) 

// statement block
{
 // enter a jQuery selector to select the currentTarget value of the event parameter
 // This function will be called when a user clicks either of the h3 elements, the selector references the h3 element the user clicks
 // The .next() method traverses the DOM tree to the element that follows the h3 element
 // Use the jQuery fadeIn() function
 $("h3").click(function() {
 	$(".ingr", "instr").event().fadeIn("slow");
 });
};

// Event listener for the h3 elements that call the display() function
$(".ingr", "instr").click("h3");
*/

function display(event)
{
	$(event.currentTarget).next("h3").fadeIn("slow");
}

$("h3").click(display);



/*
function display(event)
{
	$("h3").click(function() {
		$(".ingr").fadeIn();
	});
};

$(document).ready(function() {
	$("h3").click(function() {
		$(".ingr").fadeIn();
	});
	$("h3").click(function() {
		$(".instr").fadeIn();
	});
});
*/